<template>
    <footer class="foot">
        <div class="container">
        <div class="text-center">
            <p class="copyright">&copy; 2023 엄세원 안수진 copyright</p>
        </div>
        </div>
    </footer>
  </template>
  
  <style scoped>
.foot {
  background-color: grey;
  color: white;
  padding: 20px;
  height: 50%;
  position: relative;
  transform: translatY(-100%);
}
.copyright {
  font-size: 14px;
  text-align: center;
}
  </style>
  